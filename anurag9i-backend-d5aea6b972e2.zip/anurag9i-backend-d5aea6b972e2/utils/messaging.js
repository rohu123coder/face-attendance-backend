const express = require('express');
const axios = require('axios');
const app = express();

const admin =  require('../config/FirebaseConfig')

// Your Firebase Server Key
const firebaseServerKey = 'AAAAJz_hk_Q:APA91bHwWfULqAp5XBQkqlkyVcQoKi9ed9I9Jl4RxleHleRWAVmAs11jMh9CwDOHCqBTyRxOxeJ1NdwR3Qzj3ngDETYmUcHmYjQUKGIZFvonpZMcBMCQAmqNKL8FXMKQT7nWz2fw2VsM';

// Define the push notification function
const sendPushNotification = async (title, body, token) => {

    const options = {
        priority: "high",
        timeToLive: 60 * 60 * 24
      };

    const data = {
      to: token,
      notification: {
        title: title,
        body: body,
        icon: 'your-icon-url',
      },
    };
  
    await admin.messaging().sendToDevice(token, data, options)
      
    // const headers = {
    //   'Content-Type': 'application/json',
    //   Authorization: `key=${firebaseServerKey}`,
    // };

  
    //return axios.post('https://fcm.googleapis.com/fcm/send', data, { headers });
  }

  module.exports.sendPushNotification = sendPushNotification

