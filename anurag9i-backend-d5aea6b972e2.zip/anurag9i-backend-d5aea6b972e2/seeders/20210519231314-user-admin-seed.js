'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    /**
     * Add seed commands here.
     *
     * Example:
     * await queryInterface.bulkInsert('People', [{
     *   name: 'John Doe',
     *   isBetaMember: false
     * }], {});
    */

     return queryInterface.bulkInsert('Users', [{
      username:'admin',
      email : 'admin@admin.com',
      role:1,
      active:1,
      isLoggedIn:0,
      hash:'$2a$10$Pg9PwPB/iEbIOU.Ast.GMerphh3B4b.9OHk4rutnP0Qkrefv3j9yu',
      createdAt : new Date(),
      updatedAt : new Date(),
      
    }], {});
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add commands to revert seed here.
     *
     * Example:
     * await queryInterface.bulkDelete('People', null, {});
     */
  }
};
