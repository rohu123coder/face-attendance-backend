# node-mysql-registration-login-api

Node.js + MySQL API for User Management, Authentication and Registration

steps to follow

1. run npm install                      // install dependency
2. run npx sequelize-cli db:migrate      // migrate database
3. run npx sequelize db:seed:all             // seed admin details
4. run npm start or npm start:dev             // to run server