'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
      return Promise.all([
          queryInterface.changeColumn('FloorSKUs', 'assigned_container', {
              type: Sequelize.STRING,
              allowNull: true,
          }, )
      ])
  },

  down: (queryInterface, Sequelize) => {
      return Promise.all([
          queryInterface.changeColumn('FloorSKUs', 'assigned_container', {
              type: Sequelize.INTEGER,
              allowNull: true,
          }, )
      ])
  }
};
