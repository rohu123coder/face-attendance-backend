'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn(
        'FloorSKUs',
        'weight',
        {
          type: Sequelize.STRING,
          allowNull: true,        
        },
      ),  
         
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.removeColumn(
        'FloorSKUs',
        'weight',
      ),  
         
    ]);
  }
};
