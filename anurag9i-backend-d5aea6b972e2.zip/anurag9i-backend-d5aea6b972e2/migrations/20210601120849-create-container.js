'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Containers', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      customer_id: {
        type: Sequelize.INTEGER
      },
      container_no: {
        type: Sequelize.STRING
      },
      status: {
        type: Sequelize.STRING
      },
      checklisted: {
        type: Sequelize.BOOLEAN
      },
      seal_photo: {
        type: Sequelize.STRING
      },
      seal_comment: {
        type: Sequelize.STRING
      },
      mixed_sku: {
        type: Sequelize.BOOLEAN
      },
      other_option_setup: {
        type: Sequelize.BOOLEAN
      },
      any_damages: {
        type: Sequelize.BOOLEAN
      },
      date_activated: {
        type: Sequelize.DATE
      },
      activity: {
        type: Sequelize.STRING
      },
      net_transfer: {
        type: Sequelize.STRING
      },
      total_cbm: {
        type: Sequelize.STRING
      },
      remarks: {
        type: Sequelize.STRING
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Containers');
  }
};