'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn(
        'SKUs',
        'item_desc',
        {
          type: Sequelize.STRING,
          allowNull: true,        
        },
      ),  
         
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.changeColumn(
        'SKUs',
        'item_desc',
        {
          type: Sequelize.INTEGER,
          allowNull: true,        
        },
      ),  
         
    ]);
  }
};
