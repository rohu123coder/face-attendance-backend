'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn(
        'Containers',
        'total_skus',
        {
          type: Sequelize.STRING,
          allowNull: true,        },
      ),  
      queryInterface.addColumn(
        'Containers',
        'total_units',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),    
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
