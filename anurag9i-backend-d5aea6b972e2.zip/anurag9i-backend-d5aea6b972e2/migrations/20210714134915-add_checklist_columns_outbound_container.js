'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn(
        'OutboundContainers',
        'seal_photo',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'seal_comment',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'mixed_sku',
        {
          type: Sequelize.BOOLEAN,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'other_option_setup',
        {
          type: Sequelize.BOOLEAN,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'any_damages',
        {
          type: Sequelize.BOOLEAN,
          allowNull: true,
        },
      ),  
      queryInterface.addColumn(
        'OutboundContainers',
        'activity',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'net_transfer',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'total_cbm',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'OutboundContainers',
        'remarks',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),    
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
