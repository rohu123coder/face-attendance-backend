'use strict';
module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('Users', {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER
      },
      username: { type: Sequelize.STRING, allowNull: false },
      email: { type: Sequelize.STRING, allowNull: true },
      role: { type: Sequelize.INTEGER, allowNull: false },
      active: { type: Sequelize.BOOLEAN, default: true },
      isLoggedIn: { type: Sequelize.BOOLEAN, default: false },
      hash: { type: Sequelize.STRING, allowNull: false },
      added_by: { type: Sequelize.INTEGER, allowNull: true },
      last_logged_in:{ type: 'TIMESTAMP', allowNull: true },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('Users');
  }
};