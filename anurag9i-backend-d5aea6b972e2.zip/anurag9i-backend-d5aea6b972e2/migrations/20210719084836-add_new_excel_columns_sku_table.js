'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
     
      queryInterface.addColumn(
        'SKUs',
        'no_of_units',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'SKUs',
        'weight',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'SKUs',
        'vessel',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'SKUs',
        'destination',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),     
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
