'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    return Promise.all([
      queryInterface.addColumn(
        'Containers',
        'po_no',
        {
          type: Sequelize.STRING,
          allowNull: true,        },
      ),  
      queryInterface.addColumn(
        'Containers',
        'cbm',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'Containers',
        'item_desc',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'Containers',
        'seal_no',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'Containers',
        'destination',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'Containers',
        'no_of_units',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'Containers',
        'weight',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ),
      queryInterface.addColumn(
        'Containers',
        'vessel',
        {
          type: Sequelize.STRING,
          allowNull: true,
        },
      ), 
      queryInterface.addColumn(
        'Containers',
        'extra_fields',
        {
          type: Sequelize.STRING(2048),
          allowNull: true,
        },
      ),      
    ]);
  },

  down: async (queryInterface, Sequelize) => {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};
