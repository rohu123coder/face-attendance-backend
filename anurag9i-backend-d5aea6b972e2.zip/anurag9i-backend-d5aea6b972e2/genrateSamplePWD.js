// generatePassword.js

const bcrypt = require('bcrypt');

const plainPassword = '12345678'; // Replace this with the password you want to hash

// Generate a salt to be used for hashing the password
const saltRounds = 10;

// Generate the hash of the password
bcrypt.hash(plainPassword, saltRounds, (err, hashedPassword) => {
  if (err) {
    console.error('Error while hashing password:', err);
  } else {
    console.log('Hashed Password:', hashedPassword);
  }
});
