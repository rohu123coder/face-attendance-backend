const config = require('config.json');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const db = require('../models');
var Sequelize = require("sequelize")
var twilio = require('twilio');
const { param } = require('../controllers/user.controller');
const xlsxFile = require('read-excel-file/node');
const path = require('path');
const excelToJson = require('convert-excel-to-json');
var jsonQuery = require('json-query');
const { CIDR, NOW } = require('sequelize');

var dbconfig = require('../config/config');
var pdb = dbconfig.development;
//console.log(process.env.NODE_ENV);
var sequelize = new Sequelize(pdb.database, pdb.username, pdb.password, { dialect: pdb.dialect })

module.exports = {
    authenticate,
    getAll,
    getById,
    updatefields,
    update,
    updatePassword,
    logout,
    delete: _delete
};

async function authenticate({ username, password }) {
    const user = await db.User.findOne({ where: { username } });

    if (!user || !(await bcrypt.compare(password, user.hash)))
        throw 'Username or password is incorrect';

    // authentication successful
    Object.assign(user, { isLoggedIn: true });
    await user.save();

    const token = jwt.sign({ sub: user.id }, config.secret, { expiresIn: '7d' });

    if (user.role == 2) {
        let userReturn = await db.User.findOne(
            {
                where: {
                    id: user.id
                },
                include: [
                    {
                        model: db.Employee,
                        as: 'employee_details',
                    }, {
                        model: db.AssignedCustomer,
                        as: 'assigned_customers',
                    },
                ]
            })
        if (userReturn.access_type === 1)
            return { ...omitHash(userReturn.get()), token };
        else {
            let creationDate = getFormattedDate(userReturn.updatedAt);
            //let validDate = new Date(creationDate.getTime() + userReturn.access_time*30*60000)
            throw 'Access Denied !!!';
            //return { error: 1, message: 'user expired at'+ creationDate};            
        }

    }

    return { ...omitHash(user.get()), token };
}

function getFormattedDate(date) {
    var year = date.getFullYear();
    var month = (1 + date.getMonth()).toString();
    month = month.length > 1 ? month : '0' + month;
    var day = date.getDate().toString();
    day = day.length > 1 ? day : '0' + day;
    var dateString = year + '-' + month + '-' + day;
    return dateString;
}

async function logout(params) {
    console.log(params.id)
    const user = await db.User.findByPk(params.id);
    // logout successful
    Object.assign(user, { isLoggedIn: false });
    await user.save();
    return 'logout success'
}

async function getAll() {
    return await db.User.findAll();
}



async function getById(id) {
    return await getUser(id);
}


async function updatefields(id, params) {
    console.log(params);
    const user = await getUser(params.id);

    if (params.active) {
        params.active = !user.active
    }

    Object.assign(user, params);
    await user.save();
    return omitHash(user.get());
}

async function createOrUpdate2(model, params, condition) {
    let promise = await model.findOne({ where: condition }).then(async (obj) => {
        if (obj) {
            //console.log('updating',obj.id)
            Object.assign(obj, params);
            await obj.save();
            return { container_id: obj.id, isUpdated: true };
        } else {
            let result = await model.create(params).then((result) => result.id);
            return { container_id: result, isUpdated: false };
        }
    })

    return promise;
}



async function update(id, params) {
    const user = await getUser(id);
    console.log(params)
    // validate
    const usernameChanged = params.username && user.username !== params.username;
    if (usernameChanged && await db.User.findOne({ where: { username: params.username } })) {
        throw 'Username "' + params.username + '" is already taken';
    }

    // hash password if it was entered
    if (params.password) {
        params.hash = await bcrypt.hash(params.password, 10);
    }

    // copy params to user and save
    Object.assign(user, params);
    await user.save();

    return omitHash(user.get());
}

async function updatePassword(params) {

    let user = await db.User.findOne({ where: { username: params.username } })
    console.log("user", user);
    if (!user) {
        throw 'Username "' + params.username + '" not found';
    }

    if (!(await bcrypt.compare(params.old_password, user.hash)))
        throw 'password is incorrect';

    // hash password if it was entered
    if (params.new_password) {
        params.hash = await bcrypt.hash(params.new_password, 10);
    }

    Object.assign(user, params);
    await user.save();

    return omitHash(user.get());
}

async function _delete(id) {
    const user = await getUser(id);
    await user.destroy();
}
// helper functions
async function getUser(id) {
    let user = await db.User.findByPk(id);
    if (!user) throw 'User not found';
    console.log(user.role)

    if (user.role === 3) {
        user = await db.User.findOne({ where: { id: id }, include: [{ model: db.Customer, as: 'customer_details' }] })
        console.log(user)
    }

    if (user.role === 2) {
        user = await db.User.findOne({
            where: { id: id }, include: [{ model: db.Employee, as: 'employee_details' }, {
                model: db.AssignedCustomer,
                as: 'assigned_customers',
            }]
        })
        console.log(user)
    }

    return user;
}

function omitHash(user) {
    const { hash, ...userWithoutHash } = user;
    return userWithoutHash;
}

async function createOrUpdate(model, params, condition) {
    return await model.findOne({ where: condition }).then((obj) => {
        if (obj) {
            Object.assign(obj, params);
            return obj.save()
        } else
            return model.create(params);
    })
}